
import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

public class Server
{
    ServerSocket serv;

    public Server(int port) throws IOException
    {
        serv = new ServerSocket(port, 16);
    }

    public void run()
    {
        while (true) {
            System.out.println("Awaiting client...");

            try {
                Socket client = serv.accept();
                System.out.println("Accepted client connection");

      			PrintWriter out = new PrintWriter(client.getOutputStream(), true);
       			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

                serveClient(in, out);

                in.close();
                out.close();
                client.close();
            } catch (Exception e) {
            }    

            System.out.println("Client connection closed");
        }
    }

    public void serveClient(BufferedReader in, PrintWriter out) throws IOException
    {
        String inputLine = in.readLine();
        System.out.println("Client input: " + inputLine);
		StringTokenizer st = new StringTokenizer(inputLine, " ");

		if (st.countTokens() != 3) return;

        try {
            float a = new Float(st.nextToken()).floatValue();
            String op = st.nextToken();
            float b = new Float(st.nextToken()).floatValue();

            System.out.println("Request: " + a + " " + op + " " + b);

            float c = 0;

            if (op.equals("*"))
               c = a * b;
            else if (op.equals("/"))
               c = a / b;
            else if (op.equals("+"))
               c = a + b;
            else if (op.equals("-"))
               c = a - b;
            else
               return;

            System.out.println("Result: " + c);
            out.println(c);

        } catch (Exception e)
        {
            return;
        }
    }

    public static void main(String[] args)
    {
        if (args.length != 1) {
            System.err.println("Usage: Server <port>");
            return;
        }

        int port = 0;

        try {
            port = Integer.parseInt(args[0]);

            Server s = new Server(port);

            s.run();

        } catch (NumberFormatException e) {
            System.err.println("Illegal port number");
        } catch (IOException e) {
            System.err.println("Cannot start server");
        }
    }
}

