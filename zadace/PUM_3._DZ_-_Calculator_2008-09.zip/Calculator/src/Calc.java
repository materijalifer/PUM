import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.util.*;
import java.io.*;

class Requester extends Thread {
   String url = null;
   String request = null;
   Calc caller = null;

   public Requester(String url, String req, Calc caller)
   {
       this.url = url;
       this.request = req;
       this.caller = caller;
   }

   public String requestCalculate()
   {
       StreamConnection c = null;
       InputStream is = null;
       OutputStream os = null;

       String result = "ERROR";

       try {
           c = (StreamConnection) Connector.open(url);
           is = c.openInputStream();
           os = c.openOutputStream();

           os.write(request.getBytes());
           os.write("\r\n".getBytes());

           int ch;
           StringBuffer sb = new StringBuffer();

           while ((ch = is.read()) != -1) sb.append((char) ch);
           result = sb.toString();

           if (os != null) os.close();
           if (is != null) is.close();
           if (c != null) c.close();

       } catch (Exception e) {
           return result;
       }
       return result;
   }

   public void run()
   {
      long t = (new Date()).getTime();
      caller.showResult(requestCalculate(), (new Date()).getTime() - t);
   }

}

public class Calc extends MIDlet implements CommandListener {
   static Display display;

   Form form;
   TextField server, port, num_a, num_b;
   ChoiceGroup operator;

   Command exit_cmd, ok_cmd;

   int n_requests = 0;
   long elapsed_time = 0;

   public Calc()
   {
       display = Display.getDisplay(this);
       form = new Form("Calculator");

       server = new TextField("Server: ", "localhost", 64, TextField.ANY);
       port = new TextField("Port: ", "31337", 5, TextField.NUMERIC);
       num_a = new TextField("First: ", "0", 10, TextField.ANY);
       num_b = new TextField("Second: ", "0", 10, TextField.ANY);

       operator = new ChoiceGroup("Operator: ", ChoiceGroup.EXCLUSIVE);
       operator.append("+", null);
       operator.append("-", null);
       operator.append("*", null);
       operator.append("/", null);

       form.append(server);
       form.append(port);
       form.append(num_a);
       form.append(num_b);
       form.append(operator);

       exit_cmd = new Command("Exit", Command.EXIT, 1);
       ok_cmd = new Command("Ok", Command.OK, 1);

       form.addCommand(ok_cmd);
       form.addCommand(exit_cmd);
       form.setCommandListener(this);

       display.setCurrent(form);
   }

   public void commandAction(Command c, Displayable d)
   {
       if (d != form) {
           display.setCurrent(form);
           return;
       }

       if (c == exit_cmd) {
           destroyApp(false);
           notifyDestroyed();
       }

       if (c == ok_cmd) {
          String url = "socket://" + server.getString() + ":" + port.getString();
          String op = operator.getString(operator.getSelectedIndex());
          String a = num_a.getString();
          String b = num_b.getString();

          String req = a + " " + op + " " + b;

          Requester r = new Requester(url, req, this);
          r.start();
          return;
       }
   }

   public void showResult(String result, long time)
   {
       n_requests++;
       elapsed_time += time;
       
       Form res = new Form("Result");
       res.append(result);

       res.append("[requests: " + n_requests + "]");
       res.append("[time: " + elapsed_time + " ms]");
       res.append("[avg: " + (elapsed_time / n_requests) + " ms/req]");
       
       res.addCommand(ok_cmd);
       res.setCommandListener(this);

       display.setCurrent(res);
   }


   protected void startApp() throws MIDletStateChangeException
   {
   }

   protected void pauseApp()
   {
   }

   protected void destroyApp(boolean b)
   {
   }
}

